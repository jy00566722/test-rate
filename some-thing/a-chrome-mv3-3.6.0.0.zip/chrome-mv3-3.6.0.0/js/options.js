console.log("optionsJs is GO!!!");


//注销所有动态注入的内容脚本 或某个ID all代表所有
async function unregisterAllDynamicContentScripts(script_id) {
    //先判断浏览器版本
    if (getChromeVersion()){
      // console.log('浏览器版本大于102,OK')
    }else{
      Swal.fire("请将浏览器版本升级到102及以上,再使用!");
      return
    }
  if (!script_id) return;
  try {
    const scripts = await chrome.scripting.getRegisteredContentScripts();
    const scriptIds = scripts.map((script) => script.id);
    let list = [];
    if (script_id === "all") {
      list = scriptIds;
    } else if (scriptIds.includes(script_id)) {
      list.push(script_id);
    }
    if (list.length > 0) {
      await chrome.scripting.unregisterContentScripts({ ids: list });
    }
  } catch (error) {
    console.log(error);
    Swal.fire("出现错误,错误代码005,可以反馈给开发者。或者:请将浏览器版本升级到102及以上!");
    const message = [
      "An unexpected error occurred while",
      "unregistering dynamic content scripts.",
    ].join(" ");
    throw new Error(message, { cause: error });
  }
}
let all_permisson = {
  gmarket: {
    permissions: ["scripting"],
    origins: ["http://*.gmarket.co.kr/*", "https://*.gmarket.co.kr/*"],
    js: ["js/Underscore.js", "gmarket/gmarket.js"],
    siteName:"韩国Gmarket"
  },
  temu: {
    permissions: ["scripting", "cookies"],
    origins: ["*://*.temu.com/*"],
    js: ["js/Underscore.js", "temu/temu.js"],
    siteName:"Temu"
  },
  amazon: {
    permissions: ["scripting"],
    origins: ["https://*.amazon.com/*",
      "https://*.amazon.co.jp/*",
      "https://*.amazon.co.uk/*",
      "https://*.amazon.de/*",
      "https://*.amazon.com.br/*",
      "https://*.amazon.com.mx/*",
      "https://*.amazon.com.au/*",
      "https://*.amazon.fr/*",
      "https://*.amazon.ca/*",
      "https://*.amazon.es/*",
      "https://*.amazon.it/*",
      "https://*.amazon.in/*",  //印度
      "https://*.amazon.com.be/*",//比利时
      "https://*.amazon.sg/*",//新加坡
      "https://*.amazon.nl/*",//荷兰
      "https://*.amazon.pl/*",//波兰
      "https://*.amazon.se/*",//瑞典
      "https://*.amazon.com.tr/*",//土耳其
      "https://*.amazon.eg/*",//埃及
      "https://*.amazon.sa/*",//沙特
      "https://*.amazon.ae/*",//阿联酋

    ],
    js: ["js/Underscore.js", "amazon/amazon-all.js"],
    siteName:"亚马逊"
  },
    shopee: {
      permissions: ["scripting"],
      origins: ["https://*.xiapi.xiapibuy.cc/*",
        "https://*.xiapi.xiapibuy.com/*",
        "https://*.shopee.com.my/*",
        "https://*.shopee.ph/*",//菲律宾
        "https://*.shopee.sg/*",//新加坡
        "https://*.shopee.co.id/*",
        "https://*.shopee.tw/*",
        "https://*.shopee.co.th/*",
        "https://*.shopee.vn/*",
        "https://*.th.xiapibuy.com/*",
        "https://*.vn.xiapibuy.com/*",
        "https://*.ph.xiapibuy.com/*",
        "https://*.my.xiapibuy.com/*",
        "https://*.id.xiapibuy.com/*",
        "https://*.sg.xiapibuy.com/*",
        "https://*.shopee.com.br/*",//巴西
        "https://*.br.xiapibuy.com/*",//巴西
        "https://*.shopee.com.mx/*",//墨西哥
        "https://*.mx.xiapibuy.com/*",//墨西哥
        "https://*.shopee.com.co/*",//哥伦比亚
        "https://*.co.xiapibuy.com/*",
        "https://*.shopee.cl/*",//智利
        "https://*.cl.xiapibuy.com/*"
      ],
      js: ["js/Underscore.js", "shopee/my.js"],
      siteName:"Shopee"
    },
    lazada: {
      permissions: ["scripting"],
      origins: [
        "https://*.lazada.com.my/*",//马来西亚
        "https://*.lazada.com.ph/*",//菲律宾
        "https://*.lazada.sg/*",//新加坡
        "https://*.lazada.co.id/*",//印度尼西亚
        "https://*.lazada.vn/*",//越南
        "https://*.lazada.co.th/*"//泰国
      ],
      js: ["js/Underscore.js", "lazada/lazada_all.js"],
      siteName:"Lazada"
    },
    qoo10: {
      permissions: ["scripting"],
      origins: [
        "https://www.qoo10.jp/*"
      ],
      js: ["js/Underscore.js", "qoo10/qoo10jp.js"],
      siteName:"Qoo10"
    },
    wowmajp: {
      permissions: ["scripting"],
      origins: [
        "https://*.wowma.jp/*"
      ],
      js: ["js/Underscore.js", "wowmajp/wowmajp.js"],
      siteName:"wowmajp"
    },
    aliexpress: {
      permissions: ["scripting"],
      origins: [
        "https://*.aliexpress.com/*",
        "https://*.aliexpress.ru/*",
        "https://*.aliexpress.us/*",
      ],
      js: ["js/Underscore.js", "aliexpress/aliexpress.js"],
      siteName:"aliExpress"
    },
    //日本乐天https://www.rakuten.co.jp/站信息
    rakuten: {
      permissions: ["scripting"],
      origins: [
        "https://*.rakuten.co.jp/*",
      ],
      js: ["js/Underscore.js", "rakuten/rakuten.js"],
      siteName:"rakuten"
  }

}
//全新做权限
let allEventButton = document.querySelectorAll(".eventButton");
    allEventButton.forEach((item) => {
      item.addEventListener("click", async function () {
        let [action, site] = item.id.split("_");
          //先判断浏览器版本
        if (getChromeVersion()){
          // console.log('浏览器版本大于102,OK')
        }else{
          Swal.fire("请将浏览器版本升级到102及以上,再使用!");
          return
        }
        if (action == "start") {
          Swal.fire({
            title: "请给予权限",
            showDenyButton: true,
            // showCancelButton: true,
            html:
              "            要使用 " +
              all_permisson[`${site}`].siteName +
              " 站页面的价格转换为人民币功能,需要您授权插件访问" +
              all_permisson[`${site}`].siteName +
              "页面上的内容,请在后面的权限提示中选择<button class='button is-danger'>允许</button>。插件不会收集您的任何信息,请放心使用。",
            confirmButtonText: "确认",
            denyButtonText: `放弃`,
          }).then(async (result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
              await unregisterAllDynamicContentScripts(site);
              register(site);
            } else if (result.isDenied) {
              // Swal.fire('Changes are not saved', '', 'info')
            }
          });
        }else if(action == "stop"){
          try {
            const scripts = await chrome.scripting.getRegisteredContentScripts();
            const scriptIds = scripts.map((script) => script.id);
            if (scriptIds.includes(site)) {
              let a = await chrome.scripting.unregisterContentScripts({
                ids: [site],
              });
              Swal.fire("关闭成功");
            } else {
              Swal.fire(
                all_permisson[site].siteName + "价格转换未开启"
              );
            }
          } catch (e) {
            console.log("出错1: ", e);
            Swal.fire(
              "关闭失败,错误代码0010,可以反馈给开发者.或者:请将浏览器版本升级到102及以上!"
            );
          }
        }

      });
    });

//请求权限注册内容脚本
async function register(site) {
  chrome.permissions.request(
    {
      permissions: all_permisson[site].permissions,
      origins: all_permisson[site].origins,
    },
    async (granted) => {
      if (granted) {
        console.log("权限请求成功");
        if (site == "temu") {
          let temu_cookie = await chrome.cookies.get({
            name: "currency",
            url: "https://www.temu.com",
          });
          if (temu_cookie) {
            chrome.storage.local.set(
              { temu_cu_code: temu_cookie.value },
              function () {
                console.log("设置TEMU货币代码存入storage成功");
                chrome.scripting.registerContentScripts(
                  [
                    {
                      id: "temu",
                      matches: ["*://*.temu.com/*"],
                      js: all_permisson[site].js,
                      runAt: "document_end",
                    },
                  ],
                  (e) => {
                    console.log("注册成功");
                    Swal.fire("开启成功");
                  }
                );
              }
            );
          } else {
            console.log("未获取到temu的currency值");
            Swal.fire("开启失败,请先打开一次Temu页面");
          }
        } else {
          chrome.scripting.registerContentScripts(
            [
              {
                id: site,
                matches: all_permisson[site].origins,
                js: all_permisson[site].js,
                runAt: "document_end",
              },
            ],
            (e) => {
              console.log("注册成功");
              Swal.fire("开启成功");
            }
          );
        }
      } else {
        console.log("权限请求失败");
        Swal.fire("开启失败,错误代码007,可以反馈给开发者.或者:请将浏览器版本升级到102及以上!");
      }
    }
  );
}

//返回浏览器Chrome版本是否大于等于102
function getChromeVersion(){
  let  ua = navigator.userAgent;
  let chrome = /Chrome\/([\d]+)./i.exec(ua);
  let version = parseInt(chrome[1])
  return version >= 102
}

//给id为getStart的按钮添加点击事件
document.getElementById("getStart").addEventListener("click", getRateAndNode);

//给后台发信息,请求最新汇率及节点信息
async function getRateAndNode() {
  const response = await chrome.runtime.sendMessage({do: "getStart"});
  if (response.status==='good') {
    //用Swal2弹窗提示,在页面右上面提一个提示,显示"请求成功",1秒后自动关闭
    Swal.fire({
      position: "top-end",
      icon: "success",
      title: "请求成功",
      showConfirmButton: false,
      timer: 2000,
    });
  }
}

